package com.eloyroldan.tp_final_alojamiento.backend.Exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.core.MethodParameter;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.io.IOException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/// Cada @ExceptionHandler probado directamente (sin levantar un contexto de
/// Spring ni MockMvc): mas rapido, y alcanza para confirmar lo que realmente
/// importaba de la revision exhaustiva — que cada tipo de error mapea al
/// status code correcto, y que ninguno devuelve una traza cruda.
///
/// OJO — limite de este enfoque: esto NO prueba que Spring efectivamente elija
/// el handler mas especifico cuando hay varios candidatos en la jerarquia (ej:
/// CuentaNoVerificadaException vs AuthenticationException generico) — eso lo
/// resuelve Spring internamente por reflexion y solo se veria con un
/// @WebMvcTest real. Ver GlobalExceptionHandlerIntegrationTest si hace falta
/// blindar eso especificamente.
class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    @DisplayName("IdNoEncontradoException -> 404")
    void idNoEncontrado() {
        ResponseEntity<?> resp = handler.manejarIdNoEncontrado(new IdNoEncontradoException("no existe"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(resp.getBody()).isEqualTo("no existe");
    }

    @Test
    @DisplayName("ParametroInvalidoException -> 400")
    void parametroInvalido() {
        ResponseEntity<?> resp = handler.manejarParametroInvalido(new ParametroInvalidoException("fechas invalidas"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    @DisplayName("RecursoDuplicadoException -> 409")
    void recursoDuplicado() {
        ResponseEntity<?> resp = handler.manejarDuplicado(new RecursoDuplicadoException("email ya usado"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
    }

    @Test
    @DisplayName("MethodArgumentNotValidException (@Valid fallido) -> 400 con los campos que fallaron")
    void validacionDeCampos() {
        MethodParameter param = mock(MethodParameter.class);
        BindingResult bindingResult = mock(BindingResult.class);
        when(bindingResult.getFieldErrors()).thenReturn(List.of(
                new FieldError("dto", "email", "El formato de correo es invalido")
        ));
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(param, bindingResult);

        ResponseEntity<?> resp = handler.manejarValidacion(ex);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(resp.getBody().toString()).contains("email").contains("invalido");
    }

    @Test
    @DisplayName("UnautorizedExeption -> 401")
    void unauthorized() {
        ResponseEntity<?> resp = handler.manejarUnautorizedExeption(new UnautorizedExeption("no encontrado"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @DisplayName("CuentaNoVerificadaException -> 401 con mensaje puntual (no generico)")
    void cuentaNoVerificada() {
        ResponseEntity<?> resp = handler.manejarCuentaNoVerificada(new CuentaNoVerificadaException("verifica tu correo"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
        assertThat(resp.getBody()).isEqualTo("verifica tu correo");
    }

    @Test
    @DisplayName("DisabledException (usuario desactivado intenta loguearse) -> 401")
    void usuarioDesactivado() {
        ResponseEntity<?> resp = handler.manejarUsuarioDeshabilitado(new DisabledException("desactivado"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @DisplayName("BadCredentialsException -> 401")
    void credencialesInvalidas() {
        ResponseEntity<?> resp = handler.manejarCredencialesInvalidas(new BadCredentialsException("mal"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @DisplayName("Cualquier otra AuthenticationException no contemplada -> 401 (catch-all de seguridad)")
    void authenticationExceptionGenerica() {
        ResponseEntity<?> resp = handler.manejarAuthenticationException(new AccountExpiredException("vencida"));
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @DisplayName("MethodArgumentTypeMismatchException (ej: /Alojamiento/mostrar/abc) -> 400 con el nombre del parametro")
    void tipoDeParametroIncorrecto() {
        MethodArgumentTypeMismatchException ex = new MethodArgumentTypeMismatchException(
                "abc", Long.class, "id", null, new NumberFormatException());

        ResponseEntity<?> resp = handler.manejarTipoIncorrecto(ex);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(resp.getBody().toString()).contains("id").contains("Long");
    }

    @Test
    @DisplayName("HttpMessageNotReadableException (JSON mal formado) -> 400")
    void jsonMalFormado() throws IOException {
        HttpInputMessage inputMessage = mock(HttpInputMessage.class);
        HttpMessageNotReadableException ex = new HttpMessageNotReadableException("JSON invalido", inputMessage);

        ResponseEntity<?> resp = handler.manejarJsonMalFormado(ex);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    @DisplayName("MissingServletRequestParameterException -> 400 con el nombre del parametro faltante")
    void parametroFaltante() {
        MissingServletRequestParameterException ex = new MissingServletRequestParameterException("anio", "int");

        ResponseEntity<?> resp = handler.manejarParametroFaltante(ex);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(resp.getBody().toString()).contains("anio");
    }

    @Test
    @DisplayName("HttpRequestMethodNotSupportedException -> 405")
    void metodoNoSoportado() {
        HttpRequestMethodNotSupportedException ex = new HttpRequestMethodNotSupportedException("PATCH");

        ResponseEntity<?> resp = handler.manejarMetodoNoSoportado(ex);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
    }

    @Test
    @DisplayName("NoHandlerFoundException (ruta inexistente) -> 404 en JSON, no la pagina Whitelabel")
    void rutaInexistente() {
        NoHandlerFoundException ex = new NoHandlerFoundException("GET", "/Alojamient/typo", new HttpHeaders());

        ResponseEntity<?> resp = handler.manejarRutaInexistente(ex);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    @DisplayName("DataIntegrityViolationException (ej: condicion de carrera en un UNIQUE) -> 409, no 500 crudo")
    void integridadDeDatos() {
        ResponseEntity<?> resp = handler.manejarIntegridadDeDatos(new DataIntegrityViolationException("Duplicate entry"));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        // El mensaje NUNCA debe filtrar el detalle crudo de SQL al usuario.
        assertThat(resp.getBody().toString()).doesNotContain("Duplicate entry");
    }

    @Test
    @DisplayName("RestClientException (MercadoPago/Brevo caidos) -> 503, sin exponer el error crudo del proveedor")
    void servicioExternoCaido() {
        ResponseEntity<?> resp = handler.manejarErrorServicioExterno(new RestClientException("Connection refused"));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(resp.getBody().toString()).doesNotContain("Connection refused");
    }

    @Test
    @DisplayName("MaxUploadSizeExceededException (archivo > 10MB) -> 413")
    void archivoDemasiadoGrande() {
        ResponseEntity<?> resp = handler.manejarArchivoDemasiadoGrande(new MaxUploadSizeExceededException(10_000_000L));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.PAYLOAD_TOO_LARGE);
    }

    @Test
    @DisplayName("IllegalArgumentException (ej: ?limite=-5 en un ranking) -> 400, no 500")
    void argumentoInvalido() {
        ResponseEntity<?> resp = handler.manejarArgumentoInvalido(new IllegalArgumentException("Page size must not be less than one"));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    @DisplayName("Cualquier excepcion no contemplada -> 500 generico, SIN exponer el mensaje interno")
    void catchAllNuncaExponeElDetalleInterno() {
        ResponseEntity<?> resp = handler.manejarErrorInesperado(
                new RuntimeException("NullPointerException en la linea 245 de PagoService.java"));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        // Esta es la regla mas importante de todo el handler: jamas se filtra
        // el mensaje interno real (podria exponer nombres de clases, rutas de
        // archivo, o detalles de implementacion) al que hizo el request.
        assertThat(resp.getBody().toString())
                .doesNotContain("NullPointerException")
                .doesNotContain("PagoService.java");
    }
}
