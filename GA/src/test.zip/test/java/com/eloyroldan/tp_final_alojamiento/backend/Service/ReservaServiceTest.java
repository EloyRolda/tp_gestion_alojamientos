package com.eloyroldan.tp_final_alojamiento.backend.Service;

import com.eloyroldan.tp_final_alojamiento.backend.DTO.ReservaRegistroDTO;
import com.eloyroldan.tp_final_alojamiento.backend.Enum.ESTADORESERVA;
import com.eloyroldan.tp_final_alojamiento.backend.Enum.MOTIVOCANCELACION;
import com.eloyroldan.tp_final_alojamiento.backend.Enum.TIPOUSUARIO;
import com.eloyroldan.tp_final_alojamiento.backend.Exception.ParametroInvalidoException;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Alojamiento;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Reserva;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Usuario;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.ReservaRepository;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

/// Todas las dependencias de ReservaService mockeadas: no toca base de datos ni
/// red. El foco esta en la logica de negocio que ya nos mordio antes: motivo de
/// cancelacion segun quien cancela y cuanto falta para el check-in, validacion
/// de fechas, permisos por rol/pertenencia, y que se use el lock pesimista al
/// crear/reprogramar (no la version sin lock).
@ExtendWith(MockitoExtension.class)
class ReservaServiceTest {

    @Mock private ReservaRepository reservaRepository;
    @Mock private UsuarioService usuarioService;
    @Mock private AlojamientoService alojamientoService;
    @Mock private PagoService pagoService;

    private ReservaService reservaService;

    @BeforeEach
    void setUp() {
        // SimpleMeterRegistry real (no mockeado): registrar un contador no
        // tiene sentido mockearlo, y asi de paso confirmamos que no explota.
        MeterRegistry meterRegistry = new SimpleMeterRegistry();
        reservaService = new ReservaService(reservaRepository, usuarioService, alojamientoService, pagoService, meterRegistry);
    }

    //================================ HELPERS DE DATOS ================================

    private Usuario usuario(Long id, TIPOUSUARIO tipo, boolean activo) {
        Usuario u = new Usuario();
        u.setId(id);
        u.setTipo(tipo);
        u.setActivo(activo);
        return u;
    }

    private Alojamiento alojamiento(Long id, Usuario anfitrion, boolean activo) {
        Alojamiento a = new Alojamiento();
        a.setIdAlojamiento(id);
        a.setAnfitrion(anfitrion);
        a.setActivo(activo);
        a.setPrecioNoche(new BigDecimal("10000"));
        return a;
    }

    private Reserva reserva(Long id, Alojamiento alojamiento, Usuario cliente, ESTADORESERVA estado, LocalDate fechaInicio) {
        Reserva r = new Reserva();
        r.setIdReserva(id);
        r.setAlojamiento(alojamiento);
        r.setCliente(cliente);
        r.setEstadoReserva(estado);
        r.setFechaInicio(fechaInicio);
        r.setFechaFin(fechaInicio.plusDays(3));
        r.setPrecioNochePactado(new BigDecimal("10000"));
        return r;
    }

    //================================ crear(): validacion de fechas ================================

    @Nested
    @DisplayName("crear() - validacion de fechas")
    class CrearValidacionFechas {

        private final Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
        private final Alojamiento alojamientoActivo = alojamiento(10L, anfitrion, true);
        private final Usuario cliente = usuario(2L, TIPOUSUARIO.CLIENTE, true);

        @Test
        @DisplayName("fechaFin igual a fechaInicio -> rechaza")
        void fechaFinIgualAFechaInicio() {
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(alojamientoActivo);

            LocalDate hoy = LocalDate.now().plusDays(5);
            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(hoy);
            dto.setFechaFin(hoy);

            assertThatThrownBy(() -> reservaService.crear(dto, cliente))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("fecha de fin");
        }

        @Test
        @DisplayName("fechaFin anterior a fechaInicio -> rechaza")
        void fechaFinAnteriorAFechaInicio() {
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(alojamientoActivo);

            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(LocalDate.now().plusDays(10));
            dto.setFechaFin(LocalDate.now().plusDays(5));

            assertThatThrownBy(() -> reservaService.crear(dto, cliente))
                    .isInstanceOf(ParametroInvalidoException.class);
        }

        @Test
        @DisplayName("fechaInicio en el pasado -> rechaza")
        void fechaInicioEnElPasado() {
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(alojamientoActivo);

            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(LocalDate.now().minusDays(1));
            dto.setFechaFin(LocalDate.now().plusDays(2));

            assertThatThrownBy(() -> reservaService.crear(dto, cliente))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("dia actual");
        }

        @Test
        @DisplayName("crear() usa obtenerPorIdConLock, NUNCA obtenerPorId a secas (condicion de carrera)")
        void usaVersionConLock() {
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(alojamientoActivo);
            when(reservaRepository.existsByAlojamiento_IdAlojamientoAndEstadoReservaNotAndFechaInicioLessThanAndFechaFinGreaterThan(
                    any(), any(), any(), any())).thenReturn(false);
            when(reservaRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(LocalDate.now().plusDays(5));
            dto.setFechaFin(LocalDate.now().plusDays(8));

            reservaService.crear(dto, cliente);

            verify(alojamientoService).obtenerPorIdConLock(10L);
            verify(alojamientoService, never()).obtenerPorId(anyLong());
        }
    }

    //================================ crear(): estado activo ================================

    @Nested
    @DisplayName("crear() - alojamiento/anfitrion/cliente inactivos")
    class CrearEstadosInactivos {

        @Test
        @DisplayName("alojamiento inactivo -> rechaza")
        void alojamientoInactivo() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento inactivo = alojamiento(10L, anfitrion, false);
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(inactivo);

            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(LocalDate.now().plusDays(5));
            dto.setFechaFin(LocalDate.now().plusDays(8));

            assertThatThrownBy(() -> reservaService.crear(dto, usuario(2L, TIPOUSUARIO.CLIENTE, true)))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("inactivo");
        }

        @Test
        @DisplayName("anfitrion inactivo -> rechaza (aunque el alojamiento este activo)")
        void anfitrionInactivo() {
            Usuario anfitrionInactivo = usuario(1L, TIPOUSUARIO.ANFITRION, false);
            Alojamiento alojamientoActivo = alojamiento(10L, anfitrionInactivo, true);
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(alojamientoActivo);

            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(LocalDate.now().plusDays(5));
            dto.setFechaFin(LocalDate.now().plusDays(8));

            assertThatThrownBy(() -> reservaService.crear(dto, usuario(2L, TIPOUSUARIO.CLIENTE, true)))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("anfitrion");
        }

        @Test
        @DisplayName("fechas solapadas con otra reserva -> rechaza")
        void fechasSolapadas() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento alojamientoActivo = alojamiento(10L, anfitrion, true);
            when(alojamientoService.obtenerPorIdConLock(10L)).thenReturn(alojamientoActivo);
            when(reservaRepository.existsByAlojamiento_IdAlojamientoAndEstadoReservaNotAndFechaInicioLessThanAndFechaFinGreaterThan(
                    any(), any(), any(), any())).thenReturn(true);

            ReservaRegistroDTO dto = new ReservaRegistroDTO();
            dto.setIdAlojamiento(10L);
            dto.setFechaInicio(LocalDate.now().plusDays(5));
            dto.setFechaFin(LocalDate.now().plusDays(8));

            assertThatThrownBy(() -> reservaService.crear(dto, usuario(2L, TIPOUSUARIO.CLIENTE, true)))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("Ya existe una reserva");
        }
    }

    //================================ cancelar(): motivo segun quien y cuando ================================

    @Nested
    @DisplayName("cancelar() - determinar motivo (el corazon de la politica de reembolsos)")
    class CancelarMotivo {

        private final Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
        private final Usuario cliente = usuario(2L, TIPOUSUARIO.CLIENTE, true);
        private final Alojamiento alojamientoDelAnfitrion = alojamiento(10L, anfitrion, true);

        private ArgumentCaptor<MOTIVOCANCELACION> capturarMotivo(Reserva reserva, Usuario solicitante) {
            when(reservaRepository.findById(reserva.getIdReserva())).thenReturn(java.util.Optional.of(reserva));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(solicitante);
            when(reservaRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

            reservaService.cancelar(reserva.getIdReserva(), "no-importa@test.com");

            ArgumentCaptor<MOTIVOCANCELACION> captor = ArgumentCaptor.forClass(MOTIVOCANCELACION.class);
            verify(pagoService).ejecutarCancelacion(any(), captor.capture(), eq(null));
            return captor;
        }

        @Test
        @DisplayName("anfitrion cancela -> siempre MOTIVOCANCELACION.ANFITRION, sin importar la fecha")
        void anfitrionCancelaSiempreEsAnfitrion() {
            // fecha_inicio manana (tardia si fuera el cliente) para confirmar
            // que el motivo ANFITRION no depende para nada de la fecha.
            Reserva r = reserva(100L, alojamientoDelAnfitrion, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(1));

            ArgumentCaptor<MOTIVOCANCELACION> motivo = capturarMotivo(r, anfitrion);

            assertThat(motivo.getValue()).isEqualTo(MOTIVOCANCELACION.ANFITRION);
        }

        @Test
        @DisplayName("cliente cancela con 10 dias de anticipacion -> CLIENTE_ANTICIPADA")
        void clienteCancelaConAnticipacion() {
            Reserva r = reserva(100L, alojamientoDelAnfitrion, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(10));

            ArgumentCaptor<MOTIVOCANCELACION> motivo = capturarMotivo(r, cliente);

            assertThat(motivo.getValue()).isEqualTo(MOTIVOCANCELACION.CLIENTE_ANTICIPADA);
        }

        @Test
        @DisplayName("cliente cancela con 1 dia de anticipacion -> CLIENTE_TARDIA")
        void clienteCancelaTarde() {
            Reserva r = reserva(100L, alojamientoDelAnfitrion, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(1));

            ArgumentCaptor<MOTIVOCANCELACION> motivo = capturarMotivo(r, cliente);

            assertThat(motivo.getValue()).isEqualTo(MOTIVOCANCELACION.CLIENTE_TARDIA);
        }

        @Test
        @DisplayName("borde: exactamente 2 dias (48hs) antes del check-in -> CLIENTE_TARDIA (limite inclusive del lado tardio)")
        void bordeExactamenteDosDias() {
            Reserva r = reserva(100L, alojamientoDelAnfitrion, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(2));

            ArgumentCaptor<MOTIVOCANCELACION> motivo = capturarMotivo(r, cliente);

            assertThat(motivo.getValue()).isEqualTo(MOTIVOCANCELACION.CLIENTE_TARDIA);
        }

        @Test
        @DisplayName("borde: 3 dias antes del check-in -> ya es CLIENTE_ANTICIPADA")
        void bordeTresDias() {
            Reserva r = reserva(100L, alojamientoDelAnfitrion, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(3));

            ArgumentCaptor<MOTIVOCANCELACION> motivo = capturarMotivo(r, cliente);

            assertThat(motivo.getValue()).isEqualTo(MOTIVOCANCELACION.CLIENTE_ANTICIPADA);
        }

        @Test
        @DisplayName("admin cancela (no es dueño de nada) -> tambien puede, pero NO es motivo ANFITRION")
        void adminCancela() {
            Usuario admin = usuario(999L, TIPOUSUARIO.ADMIN, true);
            Reserva r = reserva(100L, alojamientoDelAnfitrion, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(1));

            ArgumentCaptor<MOTIVOCANCELACION> motivo = capturarMotivo(r, admin);

            // El admin no es ni cliente dueño ni anfitrion dueño: cae en la
            // misma rama que "cliente cancela", evaluada por fecha (tardia aca).
            assertThat(motivo.getValue()).isEqualTo(MOTIVOCANCELACION.CLIENTE_TARDIA);
        }
    }

    //================================ cancelar(): permisos y estado ================================

    @Nested
    @DisplayName("cancelar() - permisos y estados invalidos")
    class CancelarPermisos {

        @Test
        @DisplayName("un usuario que no es ni cliente dueño, ni anfitrion dueño, ni admin -> rechaza")
        void usuarioSinPermiso() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Usuario cliente = usuario(2L, TIPOUSUARIO.CLIENTE, true);
            Usuario intruso = usuario(3L, TIPOUSUARIO.CLIENTE, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, cliente, ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(5));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(intruso);

            assertThatThrownBy(() -> reservaService.cancelar(100L, "intruso@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("No autorizado");

            verify(pagoService, never()).ejecutarCancelacion(any(), any(), any());
        }

        @Test
        @DisplayName("cancelar una reserva ya CANCELADA -> rechaza, no se puede cancelar dos veces")
        void yaCancelada() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Usuario cliente = usuario(2L, TIPOUSUARIO.CLIENTE, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, cliente, ESTADORESERVA.CANCELADA, LocalDate.now().plusDays(5));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(cliente);

            assertThatThrownBy(() -> reservaService.cancelar(100L, "cliente@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("ya esta");
        }

        @Test
        @DisplayName("cancelar una reserva FINALIZADA -> rechaza")
        void yaFinalizada() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Usuario cliente = usuario(2L, TIPOUSUARIO.CLIENTE, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, cliente, ESTADORESERVA.FINALIZADA, LocalDate.now().minusDays(5));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(cliente);

            assertThatThrownBy(() -> reservaService.cancelar(100L, "cliente@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class);
        }
    }

    //================================ confirmar() ================================

    @Nested
    @DisplayName("confirmar()")
    class Confirmar {

        @Test
        @DisplayName("confirmar una reserva que no esta en SOLICITADA -> rechaza")
        void soloDesdeSolicitada() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, usuario(2L, TIPOUSUARIO.CLIENTE, true), ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(5));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(anfitrion);

            assertThatThrownBy(() -> reservaService.confirmar(100L, "anfitrion@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("SOLICITADA");

            verify(pagoService, never()).crearPagoParaReserva(any());
        }

        @Test
        @DisplayName("confirmar correctamente -> pasa a CONFIRMADA, setea fecha_confirmacion, y crea el Pago")
        void confirmarCorrectamente() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, usuario(2L, TIPOUSUARIO.CLIENTE, true), ESTADORESERVA.SOLICITADA, LocalDate.now().plusDays(5));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(anfitrion);
            when(reservaRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

            Reserva resultado = reservaService.confirmar(100L, "anfitrion@test.com");

            assertThat(resultado.getEstadoReserva()).isEqualTo(ESTADORESERVA.CONFIRMADA);
            assertThat(resultado.getFechaConfirmacion()).isNotNull();
            verify(pagoService).crearPagoParaReserva(resultado);
        }

        @Test
        @DisplayName("un anfitrion que no es dueño de ese alojamiento no puede confirmar")
        void anfitrionNoDuenio() {
            Usuario duenio = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Usuario otroAnfitrion = usuario(5L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento a = alojamiento(10L, duenio, true);
            Reserva r = reserva(100L, a, usuario(2L, TIPOUSUARIO.CLIENTE, true), ESTADORESERVA.SOLICITADA, LocalDate.now().plusDays(5));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(otroAnfitrion);

            assertThatThrownBy(() -> reservaService.confirmar(100L, "otro@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("No autorizado");
        }
    }

    //================================ finalizar() ================================

    @Nested
    @DisplayName("finalizar()")
    class Finalizar {

        @Test
        @DisplayName("no se puede finalizar si la fecha_fin todavia no paso")
        void fechaFinNoPaso() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            // fecha_inicio manana -> fecha_fin en el futuro, no deberia poder finalizar
            Reserva r = reserva(100L, a, usuario(2L, TIPOUSUARIO.CLIENTE, true), ESTADORESERVA.CONFIRMADA, LocalDate.now().plusDays(1));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(anfitrion);

            assertThatThrownBy(() -> reservaService.finalizar(100L, "anfitrion@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("aun no ha finalizado");

            verify(pagoService, never()).ejecutarPayoutFinalizacion(any());
        }

        @Test
        @DisplayName("solo se puede finalizar desde CONFIRMADA")
        void soloDesdeConfirmada() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, usuario(2L, TIPOUSUARIO.CLIENTE, true), ESTADORESERVA.SOLICITADA, LocalDate.now().minusDays(10));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(anfitrion);

            assertThatThrownBy(() -> reservaService.finalizar(100L, "anfitrion@test.com"))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("CONFIRMADA");
        }

        @Test
        @DisplayName("finalizar correctamente dispara el Payout del 100%%")
        void finalizarCorrectamente() {
            Usuario anfitrion = usuario(1L, TIPOUSUARIO.ANFITRION, true);
            Alojamiento a = alojamiento(10L, anfitrion, true);
            Reserva r = reserva(100L, a, usuario(2L, TIPOUSUARIO.CLIENTE, true), ESTADORESERVA.CONFIRMADA, LocalDate.now().minusDays(10));

            when(reservaRepository.findById(100L)).thenReturn(java.util.Optional.of(r));
            when(usuarioService.obtenerPorIdentificador(anyString())).thenReturn(anfitrion);
            when(reservaRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

            Reserva resultado = reservaService.finalizar(100L, "anfitrion@test.com");

            assertThat(resultado.getEstadoReserva()).isEqualTo(ESTADORESERVA.FINALIZADA);
            verify(pagoService).ejecutarPayoutFinalizacion(resultado);
        }
    }

    //================================ borrarPorId(): integridad referencial ================================

    @Nested
    @DisplayName("borrarPorId() - el fix de integridad referencial de la revision anterior")
    class BorrarPorId {

        @Test
        @DisplayName("borra el Pago ANTES que la Reserva (orden importa por la FK sin cascada)")
        void ordenDeBorrado() {
            when(reservaRepository.existsById(100L)).thenReturn(true);

            reservaService.borrarPorId(100L);

            var orden = inOrder(pagoService, reservaRepository);
            orden.verify(pagoService).borrarPorReserva(100L);
            orden.verify(reservaRepository).deleteById(100L);
        }
    }
}
