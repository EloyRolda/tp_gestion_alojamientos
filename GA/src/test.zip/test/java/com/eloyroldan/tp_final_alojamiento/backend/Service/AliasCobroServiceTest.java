package com.eloyroldan.tp_final_alojamiento.backend.Service;

import com.eloyroldan.tp_final_alojamiento.backend.DTO.Response.AliasCobroInfoDTO;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

/// AliasCobroService no tiene dependencias (ni Repository ni otro Service), asi
/// que se instancia directo, sin Mockito ni contexto de Spring — el tipo de test
/// mas rapido y barato que hay.
///
/// Los CBU de prueba de abajo no son inventados al azar: se verificaron a mano
/// corriendo el MISMO algoritmo (pesos 7,1,3,9,7,1,3 y 3,9,7,1,3,9,7,1,3,9,7,1,3)
/// en Python, por fuera de este codigo, antes de escribir el test — asi el test
/// no queda circularmente "validado por el mismo codigo que prueba".
/// 0070010800000001234565 es ademas un ejemplo publicado (no inventado) de un
/// CBU real de Banco Galicia (entidad 007).
class AliasCobroServiceTest {

    private final AliasCobroService service = new AliasCobroService();

    @Nested
    @DisplayName("CBU/CVU (22 digitos)")
    class Cbu {

        @Test
        @DisplayName("CBU valido de un banco reconocido (Banco de Galicia) -> valido, banco identificado")
        void cbuValidoBancoReconocido() {
            AliasCobroInfoDTO resultado = service.validar("0070010800000001234565");

            assertThat(resultado.isValido()).isTrue();
            assertThat(resultado.getTipo()).isEqualTo("CBU_CVU");
            assertThat(resultado.getBanco()).isEqualTo("Banco de Galicia");
        }

        @Test
        @DisplayName("CBU con digito verificador que no cierra -> invalido, sin banco")
        void cbuConDigitoVerificadorInvalido() {
            // Mismo CBU de arriba, pero con el ultimo digito cambiado a mano
            // (5 -> 4): la suma ponderada ya no da el digito verificador esperado.
            AliasCobroInfoDTO resultado = service.validar("0070010800000001234564");

            assertThat(resultado.isValido()).isFalse();
            assertThat(resultado.getBanco()).isNull();
            assertThat(resultado.getMensaje()).contains("digito verificador no cierra");
        }

        @Test
        @DisplayName("CBU con digitos verificadores correctos pero entidad fuera del mapa -> valido, banco no identificado")
        void cbuValidoBancoNoReconocido() {
            // Entidad 099 (no esta en BANCOS_POR_CODIGO), digitos verificadores
            // calculados a mano para que el CBU sea matematicamente valido igual.
            AliasCobroInfoDTO resultado = service.validar("0990001100000000000017");

            assertThat(resultado.isValido()).isTrue();
            assertThat(resultado.getTipo()).isEqualTo("CBU_CVU");
            assertThat(resultado.getBanco()).isNull();
            assertThat(resultado.getMensaje()).contains("no reconocemos el banco");
        }

        @Test
        @DisplayName("22 digitos pero el titular nunca se confirma (ni con banco reconocido)")
        void nuncaConfirmaTitular() {
            AliasCobroInfoDTO resultado = service.validar("0070010800000001234565");

            // Esto es la regla de negocio central de todo el validador: pase lo
            // que pase, el mensaje jamas debe insinuar que se confirmo a quien
            // pertenece la cuenta (no es posible por ninguna API publica).
            assertThat(resultado.getMensaje().toLowerCase())
                    .containsAnyOf("no podemos confirmar el titular", "verifica que sea tuya");
        }
    }

    @Nested
    @DisplayName("Alias (texto)")
    class Alias {

        @ParameterizedTest
        @ValueSource(strings = {"mi.alias.mp", "ALIAS-VALIDO", "abc123", "seis6c"})
        @DisplayName("Alias de 6 a 20 caracteres (letras, numeros, puntos, guiones) -> valido")
        void aliasConFormatoValido(String alias) {
            AliasCobroInfoDTO resultado = service.validar(alias);

            assertThat(resultado.isValido()).isTrue();
            assertThat(resultado.getTipo()).isEqualTo("ALIAS");
            assertThat(resultado.getBanco()).isNull(); // un alias nunca identifica banco
        }

        @Test
        @DisplayName("Alias de menos de 6 caracteres -> invalido")
        void aliasDemasiadoCorto() {
            AliasCobroInfoDTO resultado = service.validar("abc12");

            assertThat(resultado.isValido()).isFalse();
        }

        @Test
        @DisplayName("Alias con caracteres no permitidos (espacios) -> invalido")
        void aliasConCaracteresInvalidos() {
            AliasCobroInfoDTO resultado = service.validar("alias con espacios");

            assertThat(resultado.isValido()).isFalse();
        }

        @Test
        @DisplayName("Intento de inyeccion SQL como alias -> se rechaza por formato, no rompe nada")
        void aliasConIntentoDeInyeccion() {
            // No es un test de seguridad de la BD (eso lo garantiza JPA con
            // parametros preparados) — esto solo confirma que el validador de
            // formato no se cae ni deja pasar caracteres raros.
            AliasCobroInfoDTO resultado = service.validar("'; DROP TABLE usuario; --");

            assertThat(resultado.isValido()).isFalse();
        }
    }

    @Nested
    @DisplayName("Casos borde / input invalido")
    class CasosBorde {

        @Test
        @DisplayName("Valor null -> invalido, sin excepcion")
        void valorNull() {
            AliasCobroInfoDTO resultado = service.validar(null);

            assertThat(resultado.isValido()).isFalse();
            assertThat(resultado.getMensaje()).contains("no puede estar vacio");
        }

        @Test
        @DisplayName("Cadena vacia o solo espacios -> invalido, sin excepcion")
        void valorVacio() {
            assertThat(service.validar("").isValido()).isFalse();
            assertThat(service.validar("   ").isValido()).isFalse();
        }

        @Test
        @DisplayName("21 digitos (uno menos que un CBU) -> invalido, cae como formato no reconocido")
        void veintiunDigitos() {
            AliasCobroInfoDTO resultado = service.validar("007001080000000123456");

            assertThat(resultado.isValido()).isFalse();
        }

        @Test
        @DisplayName("23 digitos (uno de mas) -> invalido")
        void veintitresDigitos() {
            AliasCobroInfoDTO resultado = service.validar("00700108000000012345655");

            assertThat(resultado.isValido()).isFalse();
        }

        @Test
        @DisplayName("Espacios alrededor de un CBU valido se recortan (trim) antes de validar")
        void seRecortanEspacios() {
            AliasCobroInfoDTO resultado = service.validar("  0070010800000001234565  ");

            assertThat(resultado.isValido()).isTrue();
        }
    }
}
