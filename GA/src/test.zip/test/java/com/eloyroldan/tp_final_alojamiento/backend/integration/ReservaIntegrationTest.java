package com.eloyroldan.tp_final_alojamiento.backend.integration;

import com.eloyroldan.tp_final_alojamiento.backend.Enum.ESTADORESERVA;
import com.eloyroldan.tp_final_alojamiento.backend.Enum.TIPOUSUARIO;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Alojamiento;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Direccion;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Reserva;
import com.eloyroldan.tp_final_alojamiento.backend.Model.TipoAlojamiento;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Usuario;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.AlojamientoRepository;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.DireccionRepository;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.ReservaRepository;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.TipoAlojamientoRepository;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.UsuarioRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

/// Unico test de integracion del proyecto (por ahora): levanta un MariaDB 10.4
/// REAL en Docker (mismo motor que produccion, no H2) via Testcontainers, deja
/// que Hibernate cree el esquema desde CERO con ddl-auto=update, y confirma dos
/// cosas puntuales que un test unitario con mocks NUNCA podria haber agarrado:
///
/// 1. Sobre una base fresca, la columna GENERATED (precio_total) de Reserva
///    queda SIEMPRE null — Hibernate no sabe generar la expresion
///    "GENERATED ALWAYS AS (...)", asi que la crea como una columna comun.
///    Esto es EXACTAMENTE el bug real que tuvimos con MariaDB en desarrollo,
///    reproducido a proposito como test de regresion.
/// 2. A pesar de (1), el flujo de crear una Reserva sigue funcionando: el
///    codigo ya no depende de esa columna (PagoService.calcularMontoBase la
///    ignora a proposito, ver ese metodo).
///
/// @ServiceConnection apunta el datasource al contenedor automaticamente — no
/// hace falta un application-test.properties aparte para esto puntual.
/// Requiere Docker corriendo en la maquina donde se ejecutan los tests.
@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Testcontainers
class ReservaIntegrationTest {

    @Container
    @ServiceConnection
    static MariaDBContainer<?> mariadb = new MariaDBContainer<>("mariadb:10.4");

    @Autowired private ReservaRepository reservaRepository;
    @Autowired private AlojamientoRepository alojamientoRepository;
    @Autowired private UsuarioRepository usuarioRepository;
    @Autowired private DireccionRepository direccionRepository;
    @Autowired private TipoAlojamientoRepository tipoAlojamientoRepository;

    private Usuario nuevoUsuario(String email, TIPOUSUARIO tipo) {
        Usuario u = new Usuario();
        u.setNombre("Test");
        u.setApellido("Apellido");
        u.setUsuarioLogin(email.split("@")[0]);
        u.setEmail(email);
        u.setPassword("passwordHasheada");
        u.setTelefono("11" + System.nanoTime() % 100000000L); // unico por test
        u.setTipo(tipo);
        u.setActivo(true);
        u.setEmailVerificado(true);
        return usuarioRepository.save(u);
    }

    @Test
    @DisplayName("sobre una base MariaDB fresca, precio_total queda null (reproduce el bug real) " +
            "y aun asi el flujo de Reserva funciona sin depender de esa columna")
    void reproduceElBugDePrecioTotalYConfirmaQueYaNoImporta() {
        Usuario anfitrion = nuevoUsuario("anfitrion.it@test.com", TIPOUSUARIO.ANFITRION);
        Usuario cliente = nuevoUsuario("cliente.it@test.com", TIPOUSUARIO.CLIENTE);

        Direccion direccion = new Direccion();
        direccion.setPais("Argentina");
        direccion.setProvincia("Buenos Aires");
        direccion.setCiudad("CABA");
        direccion.setCodigoPostal("1000");
        direccion.setCalle("Calle Test");
        direccion.setAltura(100);
        direccion = direccionRepository.save(direccion);

        TipoAlojamiento tipo = tipoAlojamientoRepository.findByNombreTipoIgnoreCase("Departamento")
                .orElseGet(() -> {
                    TipoAlojamiento t = new TipoAlojamiento();
                    t.setNombreTipo("Departamento");
                    return tipoAlojamientoRepository.save(t);
                });

        Alojamiento alojamiento = new Alojamiento();
        alojamiento.setTitulo("Depto de integracion");
        alojamiento.setDescripcion("Para el test");
        alojamiento.setPrecioNoche(new BigDecimal("15000"));
        alojamiento.setCapacidad(2);
        alojamiento.setCantAmbientes(1);
        alojamiento.setCantHabitaciones(1);
        alojamiento.setCantBanios(1);
        alojamiento.setActivo(true);
        alojamiento.setAnfitrion(anfitrion);
        alojamiento.setDireccion(direccion);
        alojamiento.setTipoAlojamiento(tipo);
        alojamiento = alojamientoRepository.save(alojamiento);

        Reserva reserva = Reserva.builder()
                .fechaInicio(LocalDate.now().plusDays(5))
                .fechaFin(LocalDate.now().plusDays(8)) // 3 noches
                .precioNochePactado(new BigDecimal("15000"))
                .estadoReserva(ESTADORESERVA.SOLICITADA)
                .alojamiento(alojamiento)
                .cliente(cliente)
                .build();
        Reserva guardada = reservaRepository.save(reserva);

        // Recargar desde la base (no el objeto en memoria) para ver que
        // devuelve realmente MariaDB, no lo que quedo cacheado en Java.
        Reserva recargada = reservaRepository.findById(guardada.getIdReserva()).orElseThrow();

        // --- Confirma el bug real: en una base fresca, Hibernate crea
        //     precio_total como columna comun, sin la expresion GENERATED.
        //     Si este assert alguna vez empieza a fallar (deja de ser null),
        //     significa que Hibernate/Testcontainers cambiaron de comportamiento
        //     y esta documentacion quedo desactualizada — no es grave, pero
        //     hay que revisar el comentario de arriba.
        assertThat(recargada.getPrecioTotal()).isNull();

        // --- Confirma que, a pesar de eso, los datos que SI importan quedaron bien.
        assertThat(recargada.getPrecioNochePactado()).isEqualByComparingTo("15000");
        assertThat(recargada.getFechaInicio()).isEqualTo(LocalDate.now().plusDays(5));
        assertThat(recargada.getEstadoReserva()).isEqualTo(ESTADORESERVA.SOLICITADA);
        assertThat(recargada.getAlojamiento().getIdAlojamiento()).isEqualTo(alojamiento.getIdAlojamiento());
    }
}
