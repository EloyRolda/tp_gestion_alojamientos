package com.eloyroldan.tp_final_alojamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpFinalAlojamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
