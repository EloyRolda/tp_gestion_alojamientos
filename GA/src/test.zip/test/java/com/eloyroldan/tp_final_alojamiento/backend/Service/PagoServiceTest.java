package com.eloyroldan.tp_final_alojamiento.backend.Service;

import com.eloyroldan.tp_final_alojamiento.backend.DTO.Response.PreferenciaMercadoPagoDTO;
import com.eloyroldan.tp_final_alojamiento.backend.Enum.ESTADOPAGO;
import com.eloyroldan.tp_final_alojamiento.backend.Enum.MOTIVOCANCELACION;
import com.eloyroldan.tp_final_alojamiento.backend.Exception.ParametroInvalidoException;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Alojamiento;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Pago;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Reserva;
import com.eloyroldan.tp_final_alojamiento.backend.Model.Usuario;
import com.eloyroldan.tp_final_alojamiento.backend.Repository.PagoRepository;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/// Todas las dependencias mockeadas: nunca le pega de verdad a MercadoPago. Los
/// porcentajes de comision (@Value en el codigo real) se setean a mano con
/// ReflectionTestUtils, ya que en un test unitario puro no hay contexto de
/// Spring que los inyecte solo.
@ExtendWith(MockitoExtension.class)
class PagoServiceTest {

    @Mock private PagoRepository pagoRepository;
    @Mock private MercadoPagoService mercadoPagoService;
    @Mock private ReservaService reservaService;

    private PagoService pagoService;

    private static final BigDecimal COMISION_PLATAFORMA_PCT = new BigDecimal("5");
    private static final BigDecimal COMISION_MP_PCT = new BigDecimal("6");

    @BeforeEach
    void setUp() {
        MeterRegistry meterRegistry = new SimpleMeterRegistry();
        pagoService = new PagoService(pagoRepository, mercadoPagoService, meterRegistry, reservaService);
        ReflectionTestUtils.setField(pagoService, "comisionPlataformaPorcentaje", COMISION_PLATAFORMA_PCT);
        ReflectionTestUtils.setField(pagoService, "comisionMercadopagoEstimadaPorcentaje", COMISION_MP_PCT);
    }

    //================================ HELPERS ================================

    private Usuario anfitrion(String aliasCobro) {
        Usuario a = new Usuario();
        a.setId(1L);
        a.setAliasCobro(aliasCobro);
        return a;
    }

    private Reserva reserva(BigDecimal precioNoche, int noches, Usuario anfitrion) {
        Alojamiento alojamiento = new Alojamiento();
        alojamiento.setIdAlojamiento(10L);
        alojamiento.setTitulo("Depto de prueba");
        alojamiento.setAnfitrion(anfitrion);

        Usuario cliente = new Usuario();
        cliente.setId(2L);
        cliente.setEmail("cliente@test.com");

        Reserva r = new Reserva();
        r.setIdReserva(100L);
        r.setAlojamiento(alojamiento);
        r.setCliente(cliente);
        r.setPrecioNochePactado(precioNoche);
        r.setFechaInicio(LocalDate.now().plusDays(5));
        r.setFechaFin(LocalDate.now().plusDays(5 + noches));
        return r;
    }

    private Pago pago(ESTADOPAGO estado, BigDecimal montoBase, Reserva reserva) {
        return Pago.builder()
                .idPago(500L)
                .estado(estado)
                .montoBase(montoBase)
                .comisionPlataforma(BigDecimal.ZERO)
                .comisionMercadopago(BigDecimal.ZERO)
                .montoTotalCliente(montoBase)
                .fechaLimitePago(LocalDateTime.now().plusHours(48))
                .idPagoExterno("MP-12345")
                .reserva(reserva)
                .build();
    }

    //================================ crearPagoParaReserva(): gross-up ================================

    @Nested
    @DisplayName("crearPagoParaReserva() - calculo del gross-up")
    class CrearPago {

        @Test
        @DisplayName("el anfitrion recibe el monto base intacto: el cliente paga base + ambas comisiones")
        void calculoDeFeesCorrecto() {
            // precio_noche_pactado=10000, 3 noches -> montoBase = 30000
            Reserva r = reserva(new BigDecimal("10000"), 3, anfitrion("alias.test"));
            when(mercadoPagoService.crearPreferencia(any(), any(), any(), any()))
                    .thenReturn(new PreferenciaMercadoPagoDTO("pref-1", "https://fake-checkout"));

            pagoService.crearPagoParaReserva(r);

            var captor = ArgumentCaptor.forClass(Pago.class);
            verify(pagoRepository).save(captor.capture());
            Pago guardado = captor.getValue();

            // montoBase = 10000 * 3 = 30000
            assertThat(guardado.getMontoBase()).isEqualByComparingTo("30000");
            // comisionPlataforma = 30000 * 5% = 1500
            assertThat(guardado.getComisionPlataforma()).isEqualByComparingTo("1500.00");
            // comisionMercadopago = 30000 * 6% = 1800
            assertThat(guardado.getComisionMercadopago()).isEqualByComparingTo("1800.00");
            // montoTotalCliente = 30000 + 1500 + 1800 = 33300
            assertThat(guardado.getMontoTotalCliente()).isEqualByComparingTo("33300.00");
            assertThat(guardado.getEstado()).isEqualTo(ESTADOPAGO.PENDIENTE);
        }

        @Test
        @DisplayName("no usa Reserva.precioTotal (columna GENERATED): calcula noches*precio en Java")
        void noDependeDeLaColumnaGenerada() {
            // precio_total (columna de la BD) nunca se setea en este objeto en memoria
            // (queda null, tal como puede pasar en produccion por el bug de MariaDB
            // documentado). Si el calculo dependiera de ese campo, esto tiraria NPE.
            Reserva r = reserva(new BigDecimal("5000"), 2, anfitrion("alias.test"));
            assertThat(r.getPrecioTotal()).isNull(); // confirma la premisa del test

            when(mercadoPagoService.crearPreferencia(any(), any(), any(), any()))
                    .thenReturn(new PreferenciaMercadoPagoDTO("pref-1", "https://fake-checkout"));

            // No debe tirar NullPointerException.
            pagoService.crearPagoParaReserva(r);

            var captor = ArgumentCaptor.forClass(Pago.class);
            verify(pagoRepository).save(captor.capture());
            assertThat(captor.getValue().getMontoBase()).isEqualByComparingTo("10000"); // 5000 * 2 noches
        }

        @Test
        @DisplayName("la preferencia de MercadoPago se pide por el monto TOTAL (con fees), no el monto base")
        void sePideLaPreferenciaPorElMontoTotal() {
            Reserva r = reserva(new BigDecimal("10000"), 1, anfitrion("alias.test"));
            when(mercadoPagoService.crearPreferencia(any(), any(), any(), any()))
                    .thenReturn(new PreferenciaMercadoPagoDTO("pref-1", "https://fake-checkout"));

            pagoService.crearPagoParaReserva(r);

            // montoBase = 10000, comisiones 5%+6% = 1100 -> total = 11100
            verify(mercadoPagoService).crearPreferencia(eq("RESERVA-100"), eq(new BigDecimal("11100.00")), any(), eq("cliente@test.com"));
        }
    }

    //================================ ejecutarCancelacion(): la politica completa ================================

    @Nested
    @DisplayName("ejecutarCancelacion() - reembolsos y retenciones")
    class EjecutarCancelacion {

        @Test
        @DisplayName("CLIENTE_ANTICIPADA -> reembolso 100%% del monto base, sin Payout al anfitrion")
        void clienteAnticipada() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 2, anf); // montoBase = 20000
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("20000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.CLIENTE_ANTICIPADA, null);

            verify(mercadoPagoService).reembolsar("MP-12345", new BigDecimal("20000"));
            verify(mercadoPagoService, never()).crearPayout(any(), any(), any());
            assertThat(p.getMontoReembolsadoCliente()).isEqualByComparingTo("20000");
            assertThat(p.getMontoRetenidoAnfitrion()).isEqualByComparingTo("0");
            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.REEMBOLSADO_TOTAL);
        }

        @Test
        @DisplayName("ANFITRION cancela -> reembolso 100%% igual que CLIENTE_ANTICIPADA (nunca penaliza al cliente)")
        void anfitrionCancela() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 2, anf);
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("20000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.ANFITRION, null);

            verify(mercadoPagoService).reembolsar("MP-12345", new BigDecimal("20000"));
            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.REEMBOLSADO_TOTAL);
        }

        @Test
        @DisplayName("CLIENTE_TARDIA -> cliente recupera 65%%, anfitrion recibe 35%% via Payout")
        void clienteTardia() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 2, anf); // montoBase = 20000
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("20000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));
            when(mercadoPagoService.crearPayout(any(), any(), any())).thenReturn("PAYOUT-1");

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.CLIENTE_TARDIA, null);

            // 35% de 20000 = 7000 retenido, 65% = 13000 reembolsado
            verify(mercadoPagoService).reembolsar("MP-12345", new BigDecimal("13000.00"));
            verify(mercadoPagoService).crearPayout(eq("alias.anfitrion"), eq(new BigDecimal("7000.00")), any());
            assertThat(p.getMontoReembolsadoCliente()).isEqualByComparingTo("13000.00");
            assertThat(p.getMontoRetenidoAnfitrion()).isEqualByComparingTo("7000.00");
            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.REEMBOLSADO_PARCIAL);
        }

        @Test
        @DisplayName("ADMIN con monto igual al total -> equivale a reembolso completo (REEMBOLSADO_TOTAL)")
        void adminReembolsoCompleto() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf); // montoBase = 10000
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.ADMIN, new BigDecimal("10000"));

            verify(mercadoPagoService).reembolsar("MP-12345", new BigDecimal("10000"));
            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.REEMBOLSADO_TOTAL);
        }

        @Test
        @DisplayName("ADMIN con monto parcial -> REEMBOLSADO_PARCIAL, resto queda para el anfitrion")
        void adminReembolsoParcial() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.ADMIN, new BigDecimal("4000"));

            assertThat(p.getMontoReembolsadoCliente()).isEqualByComparingTo("4000");
            assertThat(p.getMontoRetenidoAnfitrion()).isEqualByComparingTo("6000");
            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.REEMBOLSADO_PARCIAL);
        }

        @Test
        @DisplayName("ADMIN sin monto (null) -> rechaza, es obligatorio")
        void adminSinMonto() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            assertThatThrownBy(() -> pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.ADMIN, null))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("obligatorio");
        }

        @Test
        @DisplayName("ADMIN con monto MAYOR al total de la reserva -> rechaza (fix de la revision exhaustiva)")
        void adminConMontoExcesivo() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf); // montoBase = 10000
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            assertThatThrownBy(() -> pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.ADMIN, new BigDecimal("99999")))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("no puede superar");

            verify(mercadoPagoService, never()).reembolsar(any(), any());
        }

        @Test
        @DisplayName("pago todavia PENDIENTE (nunca se pago) + VENCIMIENTO_PAGO -> pasa a VENCIDO, sin tocar MercadoPago")
        void pagoPendienteVencimiento() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PENDIENTE, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.VENCIMIENTO_PAGO, null);

            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.VENCIDO);
            verifyNoInteractions(mercadoPagoService);
        }

        @Test
        @DisplayName("pago todavia PENDIENTE + cliente cancela antes de pagar -> no hay nada que reembolsar, sin tocar MercadoPago")
        void pagoPendienteCancelacionVoluntaria() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PENDIENTE, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.CLIENTE_ANTICIPADA, null);

            // Queda PENDIENTE (no VENCIDO, eso es solo para el motivo especifico de vencimiento)
            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.PENDIENTE);
            verifyNoInteractions(mercadoPagoService);
        }

        @Test
        @DisplayName("intentar cancelar un pago que ya fue reembolsado antes -> rechaza (no se puede cancelar dos veces)")
        void yaReembolsado() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.REEMBOLSADO_TOTAL, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            assertThatThrownBy(() -> pagoService.ejecutarCancelacion(r, MOTIVOCANCELACION.CLIENTE_ANTICIPADA, null))
                    .isInstanceOf(ParametroInvalidoException.class);
        }
    }

    //================================ procesarNotificacionPago(): webhook ================================

    @Nested
    @DisplayName("procesarNotificacionPago() - robustez ante input del webhook")
    class Webhook {

        @Test
        @DisplayName("external_reference no numerica (webhook con datos basura) -> se ignora, no tira excepcion")
        void referenciaNoNumerica() {
            when(mercadoPagoService.consultarPago("999")).thenReturn(Map.of(
                    "status", "approved",
                    "external_reference", "RESERVA-no-es-un-numero"
            ));

            // No debe tirar NumberFormatException.
            pagoService.procesarNotificacionPago("999");

            verify(pagoRepository, never()).save(any());
        }

        @Test
        @DisplayName("external_reference sin el prefijo esperado -> se ignora")
        void referenciaSinPrefijo() {
            when(mercadoPagoService.consultarPago("999")).thenReturn(Map.of(
                    "status", "approved",
                    "external_reference", "OTRA-COSA-123"
            ));

            pagoService.procesarNotificacionPago("999");

            verify(pagoRepository, never()).save(any());
        }

        @Test
        @DisplayName("pago aprobado y en PENDIENTE -> pasa a PAGADO")
        void pagoAprobado() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PENDIENTE, new BigDecimal("10000"), r);
            when(mercadoPagoService.consultarPago("999")).thenReturn(Map.of(
                    "status", "approved",
                    "external_reference", "RESERVA-100"
            ));
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.procesarNotificacionPago("999");

            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.PAGADO);
            assertThat(p.getFechaPago()).isNotNull();
            verify(pagoRepository).save(p);
        }

        @Test
        @DisplayName("webhook duplicado (el pago ya estaba PAGADO) -> idempotente, no vuelve a guardar")
        void webhookDuplicadoEsIdempotente() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("10000"), r); // ya estaba pagado
            when(mercadoPagoService.consultarPago("999")).thenReturn(Map.of(
                    "status", "approved",
                    "external_reference", "RESERVA-100"
            ));
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.procesarNotificacionPago("999");

            verify(pagoRepository, never()).save(any());
        }

        @Test
        @DisplayName("pago rechazado por MercadoPago -> no se marca PAGADO")
        void pagoRechazado() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PENDIENTE, new BigDecimal("10000"), r);
            when(mercadoPagoService.consultarPago("999")).thenReturn(Map.of(
                    "status", "rejected",
                    "external_reference", "RESERVA-100"
            ));
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            pagoService.procesarNotificacionPago("999");

            assertThat(p.getEstado()).isEqualTo(ESTADOPAGO.PENDIENTE);
            verify(pagoRepository, never()).save(any());
        }
    }

    //================================ ejecutarPayoutFinalizacion() ================================

    @Nested
    @DisplayName("ejecutarPayoutFinalizacion()")
    class PayoutFinalizacion {

        @Test
        @DisplayName("anfitrion sin alias de cobro cargado -> rechaza, no se puede liquidar")
        void sinAliasCobro() {
            Usuario anfSinAlias = anfitrion(null);
            Reserva r = reserva(new BigDecimal("10000"), 1, anfSinAlias);
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            assertThatThrownBy(() -> pagoService.ejecutarPayoutFinalizacion(r))
                    .isInstanceOf(ParametroInvalidoException.class)
                    .hasMessageContaining("alias/CBU/CVU");

            verify(mercadoPagoService, never()).crearPayout(any(), any(), any());
        }

        @Test
        @DisplayName("pago no esta PAGADO -> rechaza (no se puede liquidar algo que nunca se cobro)")
        void pagoNoPagado() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 1, anf);
            Pago p = pago(ESTADOPAGO.PENDIENTE, new BigDecimal("10000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));

            assertThatThrownBy(() -> pagoService.ejecutarPayoutFinalizacion(r))
                    .isInstanceOf(ParametroInvalidoException.class);
        }

        @Test
        @DisplayName("caso feliz: transfiere el 100%% del monto base al anfitrion")
        void payoutCorrecto() {
            Usuario anf = anfitrion("alias.anfitrion");
            Reserva r = reserva(new BigDecimal("10000"), 2, anf); // montoBase = 20000
            Pago p = pago(ESTADOPAGO.PAGADO, new BigDecimal("20000"), r);
            when(pagoRepository.findByReserva_IdReserva(100L)).thenReturn(Optional.of(p));
            when(mercadoPagoService.crearPayout(any(), any(), any())).thenReturn("PAYOUT-XYZ");

            pagoService.ejecutarPayoutFinalizacion(r);

            verify(mercadoPagoService).crearPayout(eq("alias.anfitrion"), eq(new BigDecimal("20000")), any());
            assertThat(p.getMontoRetenidoAnfitrion()).isEqualByComparingTo("20000");
            assertThat(p.getIdTransferenciaExterna()).isEqualTo("PAYOUT-XYZ");
            assertThat(p.getFechaTransferencia()).isNotNull();
        }
    }
}
